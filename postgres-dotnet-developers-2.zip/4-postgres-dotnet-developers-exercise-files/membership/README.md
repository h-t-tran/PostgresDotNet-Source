Sample Code for the Postgres for .NET Developers video at Pluralsight
============

This is a simple console app with Command/Query ideas that play really, really closely with ADO.NET and NpgSQL. You might like it, you might hate it.
