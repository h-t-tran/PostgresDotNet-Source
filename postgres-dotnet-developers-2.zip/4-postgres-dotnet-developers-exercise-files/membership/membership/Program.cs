﻿using Membership.DataAccess;
using Membership.Models;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Membership
{
  class Program
  {
    static void Main(string[] args)
    {
      var db = new CommandRunner("dvds");
      // follow along here...
   
      Console.Read();
    }
  }
}
