﻿using Membership.DataAccess;
using Membership.Models;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Membership
{
  class Program
  {
    static void Main(string[] args)
    {
      var db = new CommandRunner("dvds");
      var q = new Commands.Membership.RegisterCommand(db);
      q.Email = "rob@datachomp.com";
      q.Password = "password";
      q.Confirmation = "password";
      q.First = "Bob";
      q.Last = "Sullivan";
      var result = q.Execute();
      Console.WriteLine("The new ID is {0} and message is {1}", result.NewUserID, result.Message);
      Console.Read();
    }
  }
}
