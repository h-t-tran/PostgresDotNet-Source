﻿using Membership.DataAccess;
using Membership.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Membership.Queries.Sales
{
  public class SalesOrderQuery
  {
    ICommandRunner Runner;
    public SalesOrderQuery(ICommandRunner runner)
    {
      Runner = runner;
    }

    public int? ID { get; set; }
    public string Key { get; set; }

    public SalesOrder Execute()
    {
      var sqlFormat = "SELECT * from sales_order where {0}=@0";
      object arg;
      var sql="";
      if (ID.HasValue)
      {
        sql = String.Format(sqlFormat, "id");
        arg = this.ID.Value;
      }
      else if (!String.IsNullOrWhiteSpace(Key))
      {
        sql = String.Format(sqlFormat, "sales_order_key");
        arg = this.Key;
      }
      else
      {
        throw new InvalidOperationException("Need to set ID or Key");
      }

      var record = Runner.ExecuteSingleDynamic(sql, arg);
      var result = new SalesOrder();
      result.ID = record.id;
      result.Key = record.sales_order_key;
      result.Items = JsonConvert.DeserializeObject<List<LineItem>>(record.data);
      return result;

    }

  }
}
